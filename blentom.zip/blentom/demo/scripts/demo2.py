from blentom import Atom, Atoms, interactive, reset

reset()

"""
H = Atom("H")
interactive()
"""

Atoms.read("/Users/dominik/Desktop/blentom/demo/data/XDATCAR")
