Asset Class
^^^^^^^^^^^

.. autoclass:: src.asset.Asset
   :members:
   :special-members:
   :show-inheritance:
