Helpful Function
^^^^^^^^^^^^^^^^

.. automodule:: src.lib
   :members:
   :special-members: