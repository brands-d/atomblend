Camera
^^^^^^
Use one or more cameras to set the scene. Cameras also abstract the rendering process itself. You can have many different independent cameras and can render from any of them.

.. autoclass:: src.camera.Camera
   :show-inheritance:
   :members:
   :special-members:
