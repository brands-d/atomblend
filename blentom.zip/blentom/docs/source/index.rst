.. include:: ../../README.rst
   
.. toctree::
   :maxdepth: 3
   
   introduction
   howto
   documentation
