Light
^^^^^

.. autoclass:: src.light.Light
   :members:
   :special-members:
   :show-inheritance: